define(["exports","./vendor-22992e2c"],(function(e,t){"use strict";e.useUserContext=({store:e})=>t.computed((()=>e.getters["runtime/auth/isUserContextReady"]))}));
